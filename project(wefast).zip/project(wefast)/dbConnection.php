<?php
$db_host="locathost";
$db_user="root";
$db_password="mysql";
$db_name="project_1";

//Create Connection
 $con=mysqli_connect("localhost","root","mysql");
 if(!con)
 {
 echo "not connect";
 }
 if(!mysqli_select_db($con,'project_1'))
 {
  echo"not selecting";
 }
 //else
 //{
 //echo"connect";
 //}

?>