<div class="col-md-6"><!--Comments-->
<form action="" method="POST">
<input type="text" class="form-control" name="name" placeholder="Name"><br>
<input type="text" class="form-control" name="subject" placeholder="Subject"><br>
<input type="email" class="form-control" name="email" placeholder="Email"><br>
<textarea class="form-control" name="message" height="500" placeholder="How can we help you? " ></textarea><br>
<input type="submit" class="btn btn-primary" value="Send" name="submit"><br><br>


</form>
</div>