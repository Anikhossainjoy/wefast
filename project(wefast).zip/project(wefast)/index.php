<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatiable" content="ie=edge">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/all.min.css">
<link rel="stylesheet" href="css/custom.css">
<title>We Fast</title>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-danger pl-5 fixed-top">
<a href="index.php" class="navbar-brand">We Fast</a>
<span class="navbar-text">Customer's Happiness is our Aim</span>
<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#myMenu">
<span class="navbar-toggle-icon "></span>
</button>
<div class="collapse navbar-collapse" id="myMenu">

<ul class="navbar-nav pl-6 custom-nav" >
<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
<li class="nav-item"><a href="#Service" class="nav-link">Services</a></li>
<li class="nav-item"><a href="#Registration" class="nav-link">Registration</a></li>
<li class="nav-item"><a href="Requester/requesterlogin.php" class="nav-link">Login</a></li>
<li class="nav-item"><a href="#Contact" class="nav-link">Contact</a></li>

</ul>
</div>
</nav>
<!--Strater header-->
<header class="jumbotron back-image" style="background-image:url(images/dd.jpeg);">
<div class="myclass mainHeading">
<h1 class="text-uppercase text-danger font-weight-bold">Welcome to We Fast </h1>
<p class="font-italic">Customer' Happiness is our Aim</p>
<a href="Requester/requesterlogin.php" class="btn btn-success mr-4">Login</a>
<a href="#Registration" class="btn btn-danger mr-4">Signup</a>
</div>
</header>
<!--we start into the session fast paragraph-->
<div class="container">
<div class="jumbotron">
<h3 class="text-center">We fast </h3>
<p>hi we are a team
</p>
</div>
</div>
<!-- START SERIVCE SESSION-->
<div class="container text-center border-bottom"  id="Service">
<h2>Our service</h2>
<div class="row mt-4">
<div class="col-sm-5 mb-4 mr-5">
<a href="#"><i class="fas fa-car fa-8x"></i></a>
<h6 class="mt-4">We provide convenient courier service</h6>
</div>
<div class="col-sm-5 mb-4 ml-5">
<a href="#"><i class="fas fa-user fa-male fa-8x text-success text-primary"></i></a>
<h6 class="mt-4">We provide convenient courier person</h6>
</div>
</div>
</div>
<!--Registration form-->
<?php include('UserRegistration.php')?>
<!--start happy customer-->
<div class="jumbotron bg-success">
<div class="container">
<h2 class="text-center text-white">FeedBack of Customers</h2>
<div class="row">
<div class="col-lg-4 col-sm-4">
<div class="card shadow-lg mb-2">
<div class="card-body text-center">
<img src="images/avtar1.jpg" style="border-radius:100px;"  alt="no photo" height="42" width="42">
<h4 class="card-title">Captain</h4>
<p class="card-text"> its very good site and i am pleased it service.</p>
</div>
</div>
</div>
<!--2nd customer-->
<div class="col-lg-4 col-sm-4">
<div class="card shadow-lg mb-2">
<div class="card-body text-center">
<img src="images/avtar1.jpg" style="border-radius:100px;"  alt="no photo" height="42" width="42">
<h4 class="card-title">Captain</h4>
<p class="card-text"> its very good site and i am pleased it service.</p>
</div>
</div>
</div>
<!--3rd customer-->
<div class="col-lg-4 col-sm-4">
<div class="card shadow-lg mb-2">
<div class="card-body text-center">
<img src="images/avtar1.jpg" style="border-radius:100px;"  alt="no photo" height="42" width="42">
<h4 class="card-title">Captain</h4>
<p class="card-text"> its very good site and i am pleased it service.</p>
</div>
</div>
</div>
</div>
</div>
</div>
<!--Start Contact us-->
<footer class="jumbotron back-image"  style="background-image:url(images/ww.jpg);">
<div class="container" id="Contact">
<h2 class="text-center mb-4">Contact Us</h2>
<div class="row">
<!--1st Comments-->
<?php include('contactform.php')?>


<div class="col-md-6 text-center"><!--start 2nd comment-->
<strong>Headquater:
</strong><br>
We fast pvt Limited<br>
Dhaka,Bangladesh<br>
Phone:147258369<br>
<a href="#" target="_blank">www.wefast.com</a><br>

</div>
</div>
</div>
</footer>
<!--Footer-->
<footer class="container-fluid bg-dark mt-5 text-white">
<div class="container">
<div class="row py-3">
<div class="col-md-6 ">
<span class="pr-2">Follow Us:</span>
<a href="#" target="_blank" class="pr-2 fi-color"<i class="fab fa-facebook"></i></a>
<a href="#" target="_blank" class="pr-2 fi-color"<i class="fab fa-twitter"></i></a>
<a href="#" target="_blank" class="pr-2 fi-color"<i class="fab fa-youtube"></i></a>
<a href="#" target="_blank" class="pr-2 fi-color"<i class="fab fa-google-plus-g"></i></a>
<a href="#" target="_blank" class="pr-2 fi-color"<i class="fab fa-rss"></i></a>
</div>
<div class="col-md-6 text-right"><!---2nd-->
<small>Design by Anik &copy; 2020</small>
<small class="ml-2 "><a href="Admin/login.php">Admin Login</a></small>
</div>
</div>
</div>
</footer>

<!--JAvaScript-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/all.min.js"></script>
</body>
</html> 