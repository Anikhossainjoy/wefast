<?php
define('TITLE','Work report');
define('PAGE','workreport');
include('includes/header.php');
include('../dbConnection.php');
?>
<?php
include('includes/footer.php');
?>