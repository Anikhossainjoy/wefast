<?php
if(session_id()=='')
{
session_start();
}
if(isset($_SESSION['is_adminlogin']))
{
$aEmail=$_SESSION['aEmail'];
}
else
{
echo"<script>location.href='login.php'</script>";
}
 
if (isset($_REQUEST['view'])){
$sql="SELECT * FROM submitrequest_tb WHERE request_id={$_REQUEST['id']}";
$result=$con->query($sql);
$row=$result->fetch_assoc();
}
if(isset($_REQUEST['close']))
{
$sql="DELETE FROM submitrequest_tb WHERE request_id={$_REQUEST['id']}";
if($con->query($sql)==TRUE)
{
echo '<meta http-equiv="refresh" content="0;URL=?closed"/>';

}
else{
echo "Unable to Delete";
}

}

//assign for work
if(isset($_REQUEST['assign'])){
if(($_REQUEST['request_id']=="")||($_REQUEST['requestinfo']=="")||($_REQUEST['requestdesc']=="")||($_REQUEST['requestername']=="")||($_REQUEST['requesteradd1']=="")||($_REQUEST['requesteradd2']=="")||($_REQUEST['requestercity']=="")||($_REQUEST['requesterstate']=="")||($_REQUEST['requesterzip']=="")||($_REQUEST['requesteremail']=="")||($_REQUEST['requestermobile']=="")||($_REQUEST['assigntech']=="")||($_REQUEST['requesterdate']==""))
{
$msg= '<div class="alert alert-warning col-sm-6 ml-5 mt-2 "role="alert">Fill All Field</div>';
}
else
{
$rid=$_REQUEST['request_id'];
$rinfo=$_REQUEST['requestinfo'];
$rdesc=$_REQUEST['requestdesc'];
$rname=$_REQUEST['requestername'];
$radd1=$_REQUEST['requesteradd1'];
$radd2=$_REQUEST['requesteradd2'];
$rcity=$_REQUEST['requestercity'];
$rstate=$_REQUEST['requesterstate'];
$rzip=$_REQUEST['requesterzip'];
$remail=$_REQUEST['requesteremail'];
$rmobile=$_REQUEST['requestermobile'];
$rassigntech=$_REQUEST['assigntech'];
$rdate=$_REQUEST['requesterdate'];

$sql="INSERT INTO assignwork_tb(request_id,request_info,request_desc,requester_name,requester_add1,requester_add2,requester_city,requester_state,requester_zip,requester_email,requester_mobile,assign_tech,assign_date)VALUES('$rid','$rinfo','$rdesc','$rname','$radd1','$radd2','$rcity','$rstate','$rzip','$remail','$rmobile','$rassigntech','$rdate')";
if($con->query($sql)==TRUE)
{
$msg= '<div class="alert alert-success col-sm-6 ml-5 mt-2">Work Assigned </div>';
}
else
{
$msg= '<div class="alert alert-danger col-sm-6 ml-5 mt-2">Unable to assign work</div>';
}

}

}


?>


<!--Start Service Request Form 3nd Column-->

<div class="col-sm-5 mt-5 jumbotron">
<form  action="" method="POST">
<h5 class="text-center">Assign Work Order Request</h5>
<div class="form-group">
<label for="request_id">Request ID</label>
<input type="text" class="form-control" id="request_id"  name="request_id" value="<?php if (isset($row['request_id'])) echo $row['request_id'];?>" readonly>
</div>
<div class="form-group">
<label for="inputRequestInfo">Request Info</label>
<input type="text" class="form-control" id="inputRequestInfo"  name="requestinfo" value="<?php if (isset($row['request_info'])) echo $row['request_info'];?>">
</div>
<div class="form-group">
<label for="inputRequestDescription">Description</label>
<input type="text" class="form-control" id="inputRequestDescription"  name="requestdesc"value="<?php if (isset($row['requester_desc'])) echo $row['requester_desc'];?>">
</div>
<div class="form-group">
<label for="inputName">Name</label>
<input type="text" class="form-control" id="inputName"  name="requestername"value="<?php if (isset($row['requester_name'])) echo $row['requester_name'];?>">


</div>
<div class="form-row">
<div class="form-group col-md-6">
<label for="inputAddress">Address Line </label>
<input type="text" class="form-control" id="inputAddress" name="requesteradd1" value="<?php if (isset($row['requester_add1'])) echo $row['requester_add1'];?>">
</div>
<div class="form-group col-md-6">
<label for="inputAddress2">Destination Address </label>
<input type="text" class="form-control" id="inputAddress2"  name="requesteradd2"value="<?php if (isset($row['requester_add2'])) echo $row['requester_add2'];?>">

</div>
</div>
<div class="form-row">
<div class="form-group col-md-6">
<label for="inputCity">City</label>
<input type="text" class="form-control" id="inputCity"  name="requestercity"value="<?php if (isset($row['requester_city'])) echo $row['requester_city'];?>">
</div>
<div class="form-group col-md-4">
<label for="inputState">State</label>
<input type="text" class="form-control" id="inputState"  name="requesterstate"value="<?php if (isset($row['requester_state'])) echo $row['requester_state'];?>">
</div>
<div class="form-group col-md-2">
<label for="inputZip">Zip</label>
<input type="number" class="form-control" id="inputZip" name="requesterzip" onkeypress="isInputNumber(event)" value="<?php if (isset($row['requester_zip'])) echo $row['requester_zip'];?>">
</div>

</div>
<div class="form-row">
<div class="form-group col-md-6">
<label for="inputEmail">Email</label>
<input type="email" class="form-control" id="inputEmail"  name="requesteremail"value="<?php if (isset($row['requester_email'])) echo $row['requester_email'];?>">
</div>
<div class="form-group col-md-4">
<label for="inputMobile">Mobile</label>
<input type="number" class="form-control" id="inputMobile"name="requestermobile" onkeypress="isInputNumber(event)"
 value="<?php if (isset($row['requester_mobile'])) echo $row['requester_mobile'];?>">
</div>

</div>

<div class="form-row">
<div class="form-group col-md-6">
<label for="assigntech">Assign to CourierMan</label>
<input type="text" class="form-control" id="assigntech"  name="assigntech">
</div>

<div class="form-group col-md-6">
<label for="inputDate">Date</label>
<input type="date" class="form-control" id="inputDate"  name="requesterdate"  >
</div>

</div>
<div class="float-right">
<button type="submit" class="btn btn-success" name="assign">Assign
</button>
<button type="reset" class="btn btn-secondary" >Reset
</button>
</div>

</form>
<?php if(isset($msg)){echo $msg;}?>

</div>

