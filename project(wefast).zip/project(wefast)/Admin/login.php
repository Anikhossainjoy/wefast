<?php
include('../dbConnection.php');
session_start();
if(!isset($_SESSION['is_adminlogin'])){
if(isset($_REQUEST['aEmail'])){
$aEmail=mysqli_real_escape_string($con,trim($_REQUEST['aEmail']));//for secure login system
$aPassword=mysqli_real_escape_string($con,trim($_REQUEST['aPassword']));
$sql="SELECT a_email,a_password FROM adminlogin_tb WHERE a_email='".$aEmail."'AND a_password='".$aPassword."' limit 1 ";
$result=$con->query($sql);
if($result->num_rows==1){
$_SESSION['is_adminlogin']=true;
$_SESSION['aEmail']=$aEmail;
echo"<script>location.href='dashboard.php';</script>";
exit;
}
else
{
$msg='<div class="alert alert-warning mt-2">Login is not Successful</div>';
}
}
}
else
{
echo"<script>location.href='dashboard.php';</script>";
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatiable" content="ie=edge">
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/all.min.css">
<link rel="stylesheet" href="../css/custom.css">
<title>Login Form</title>

</head>
<body>
<div class="mb-3 mt-5 text-center " style="font-size:30px;">
<i class="fas fa-car"></i>
<span>Online courier management system </span>
</div>
<p class="text-center "style="font-size:20px"><i class="fas fa-user-secret text-danger"></i>Admin Area</p>
<div class="container-fluid">
<div class="row justify-content-center mt-5">
<div class="col-sm-6 col-md-4">
<form action="" class="shadow-lg p-4"  method="POST">
<div class="form-gruop">
<i class="fas fa-user"></i><label for="email" class="font-weight-bold pl-3">Email</label><br>
<input type="email" class="form-control"  name="aEmail" placeholder="Email" >
<small class="form-text">we never share your information</small>
</div>
<div class="form-gruop">
<i class="fas fa-key"></i><label for="pass" class="font-weight-bold pl-2">Password</label><br>
<input type="password" class="form-control" placeholder="Password"  name="aPassword">

</div>
<button type="submit" class="btn btn-outline-danger mt-4 shadow-sm font-weight-bold btn-block">Login
</button>
<?php if(isset($msg)){echo $msg;}  ?>
<div class="text-center"><a href="../index.php" class="btn btn-info mt-3 font-weight-bold shadow-sm">Back to Home</a>

</div>
</form>
</div>
</div>
</div>

<!--JAvaScript-->
<script src="../js/jquery.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/all.min.js"></script>
</body>
</html>