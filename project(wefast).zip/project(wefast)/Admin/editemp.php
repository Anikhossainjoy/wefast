<?php
define('TITLE','Update Courier');
define('PAGE','technician');
include('includes/header.php');
include('../dbConnection.php');
session_start();
if(isset($_SESSION['is_adminlogin']))
{
$aEmail=$_SESSION['aEmail'];
}
else
{
echo"<script>location.href='login.php'</script>";
}
?>
<!--Start 2nd cl-->
<div class="col-sm-6 mt-5 mx-3 jumbotron">
<h3 class="text-center">Update Courier Man Details</h3>

<?php
if(isset($_REQUEST['edit'])){
$sql="SELECT * FROM courierman_tb WHERE empid={$_REQUEST['id']}";
$result=$con->query($sql);
$row=$result->fetch_assoc();
}
if(isset($_REQUEST['empupdate'])){
if(($_REQUEST['empName']=="")||($_REQUEST['empCity']=="")||($_REQUEST['empMobile']=="")||($_REQUEST['empEmail']=="")){
$msg='<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert">Fill all the fields</div>';
}
else{
$eid=$_REQUEST['empid'];
$eName=$_REQUEST['empName'];
$eCity=$_REQUEST['empCity'];
$eMobile=$_REQUEST['eMobile'];
$eEmail=$_REQUEST['eEmail'];
$sql="UPDATE courierman_tb SET empName='$eName',empCity='$eCity',empMobile='$emobile',empEmail='$eEmail' WHERE empid = '$eId'  ";
if($con->query($sql)==TRUE)
{
$msg='<div class="alert alert-success col-sm-6 ml-5 mt-2" role="alert">Update Successfully</div>';
}
else{
$msg='<div class="alert alert-danger col-sm-6 ml-5 mt-2" role="alert">Not updated</div>';
}
}

}
?>
<style>
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
​
/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
input::-webkit-calendar-picker-indicator{
display:none;
}

</style>
<form action="" method="POST">
<div class="form-group">
<label for="empid">Emp Id</label>
<input type="text" class="form-control" name="empId" id="empid" value="<?php if(isset($row['empid'])){echo $row['empid'];} ?>" readonly>
</div>
<div class="form-group">
<label for="empName">Emp Name</label>
<input type="text" class="form-control" name="empName" id="empName" value="<?php if(isset($row['empName'])){echo $row['empName'];} ?>" >
</div>
<div class="form-group">
<label for="empCity">City</label>
<input type="text" class="form-control" name="empCity" id="empCity" value="<?php if(isset($row['empCity'])){echo $row['empCity'];} ?>" >
</div>
<div class="form-group">
<label for="empMobile">Mobile</label>
<input type="number" class="form-control" name="empMobile" id="empMobile" value="<?php if(isset($row['empMobile'])){echo $row['empMobile'];} ?>" >
</div>
<div class="form-group">
<label for="empEmail">Email</label>
<input type="email" class="form-control" name="empEmail" id="empEmail" value="<?php if(isset($row['empEmail'])){echo $row['empEmail'];} ?>" >
</div>



<div class="text-center">
<button type="submit" class="btn btn-danger" id="empupdate" name="empupdate">Update</button>

<a href="technician.php"  class="btn btn-secondary">Close</a>
</div>
<?php if(isset($msg)){echo $msg;}?>
</form>
</div>


<?php
include('includes/footer.php');
?>