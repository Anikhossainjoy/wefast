<?php
define('TITLE','ChangePassword');
define('PAGE','changepass');
include('includes/header.php');
include('../dbConnection.php');
session_start();
if(isset($_SESSION['is_adminlogin']))
{
$aEmail=$_SESSION['aEmail'];
}
else
{
echo"<script>location.href='login.php'</script>";
}
if(isset($_REQUEST['passupdate']))
{
if($_REQUEST['rPassword']=="")
{
$passmsg='<div class="alert alert-warning col-sm-7  mt-2">Fill All Field</div>';
}
else{
$rPass=$_REQUEST['rPassword'];
$sql="UPDATE adminlogin_tb SET r_password ='$rPass' WHERE r_email='$rEmail' ";
if($con->query($sql)== TRUE){
$passmsg='<div class="alert alert-success col-sm-7   mt-2">Updated success</div>';
}
else
{
$passmsg='<div class="alert alert-danger col-sm-6 ml-5 mt-2">Not Updated</div>';
}

}

}


?>
<div class="col-sm-9 col-md-5"><!--Start change password form 2nd column-->

<form class="mt-5 mx-5"  action="" method="POST">
<div class="form-group">
<label for="inputEmail">Email</label><input type="email" class="form-control" name="rEmail" id="rEmail" value="<?php echo $rEmail; ?>" readonly>
</div>
<div class="form-group">
<label for="inputnewpassword">New Password </label><input type="password" class="form-control" name="rPassword" id="inputnewpassword" placeholder="New Password">
</div>
<button type="submit" class="btn btn-danger mr-4 mt-4"name="passupdate">Update
</button>
<button type="reset" class="btn btn-secondary mt-4" >Reset
</button>
<?php if(isset($passmsg)){echo $passmsg ;}?>
</form>
</div>

?>
<?php
include('includes/footer.php');
?>