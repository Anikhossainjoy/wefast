<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatiable" content="ie=edge">
<!--boostrasp css,font awsome,custom css-->
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/all.min.css">
<link rel="stylesheet" href="../css/custom.css">
<title><?php echo TITLE ?></title>
</head>
<body>
<!--top navbar-->
<nav class="navbar nav-dark fixed-top bg-success flex-md-nowrap p-10 shadow "><a class="navbar-brand col-sm-3 col-md-2 mr-0 text-white" href="dashboard.php">WeFast</a></nav>
<!--container-->
<div class="container-fluid" style="margin-top:40px;">
<div class="row"><!--row-->
<nav class="col-sm-2 bg-light sidebar py-5 d-print-none"><!--sidebar 1st column-->
<div class="sidebar-sticky">
<ul class="nav flex-column">
<li class="nav-item"><a class="nav-link <?php if (PAGE=='dashboard'){echo 'active';}?> " href="dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='work'){echo 'active';}?> " href="work.php"><i class="fab fa-accessible-icon"></i>Work Order</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='request'){echo 'active';}?>" href="request.php"><i class="fas fa-align-center"></i>Requests</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='assets'){echo 'active';}?>" href="assets.php"><i class="fas fa-align-center"></i>Assets</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='technician'){echo 'active';}?>" href="technician.php"><i class="fas fa-user"></i>CourierMan</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='requesters'){echo 'active';}?>" href="requesters.php"><i class="fas fa-table"></i>Requesters</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='soldproductreport'){echo 'active';}?>" href="soldproductreport.php"><i class="fas fa-align-center"></i>Sell Report</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='workreport'){echo 'active';}?>" href="workreport.php"><i class="fas fa-table"></i>Work report</a></li>

<li class="nav-item"><a class="nav-link <?php if (PAGE=='changepass'){echo 'active';}?>" href="changepass.php"><i class="fas fa-key"></i>Change Password</a></li>
<li class="nav-item"><a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
</ul>
</div>
</nav>