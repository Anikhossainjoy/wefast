<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatiable" content="ie=edge">
<!--boostrasp css,font awsome,custom css-->
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/all.min.css">
<link rel="stylesheet" href="../css/custom.css">
<title><?php echo TITLE ?></title>

</head>
<body>
<!--top navbar-->
<nav class="navbar nav-dark fixed-top bg-success flex-md-nowrap p-10 shadow "><a class="navbar-brand col-sm-3 col-md-2 mr-0 text-white" href="Requesterprofile.php">WeFast</a></nav>
<!--container-->
<div class="container-fluid" style="margin-top:40px;">
<div class="row"><!--row-->
<nav class="col-sm-2 bg-light sidebar py-5 d-print-none"><!--sidebar 1st column-->
<div class="sidebar-sticky">
<ul class="nav flex-column">
<li class="nav-item"><a class="nav-link <?php if (PAGE=='RequesterProfile'){echo 'active';}?> " href="RequesterProfile.php"><i class="fas fa-user"></i>Profile</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='SubmitRequest'){echo 'active';}?> " href="SubmitRequest.php"><i class="fab fa-accessible-icon"></i>Submit Request</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='CheckStatus'){echo 'active';}?>" href="CheckStatus.php"><i class="fas fa-align-center"></i>Check Status</a></li>
<li class="nav-item"><a class="nav-link <?php if (PAGE=='Requesterchangepass'){echo 'active';}?>" href="Requesterchangepass.php"><i class="fas fa-key"></i>Change Password</a></li>
<li class="nav-item"><a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
</ul>
</div>
</nav>

