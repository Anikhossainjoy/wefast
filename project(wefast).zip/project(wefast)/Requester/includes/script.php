﻿<!DOCTYPE html>
<html>
    <head>
        <title>Javascript - Input Text Allow Only Numbers</title>
        <meta charset="windows-1252">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
        <input type="text" onkeypress="isInputNumber(event)">
        
        <script>
            
            function isInputNumber(evt){
                
                var ch = String.fromCharCode(evt.which);
                
                if(!(/[0-9]/.test(ch))){
                    evt.preventDefault();
                }
                
            }
            
        </script>
       
    </body>
</html>
